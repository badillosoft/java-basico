package cic;

import java.util.*;
import java.io.*;

public class Packer {
    
    private ArrayList<File> files = new ArrayList();
    private String path = "C:/archivos";
    private String base_name = "my_file.pack";
    private String meta_name = "my_file.meta";

    void addFile(String filename) {
        files.add(new File(filename));
    }
    
    void addFile(File file) {
        files.add(file);
    }
    
    int sizeOfFile(File f) throws IOException {
        FileReader fr = new FileReader(f);
        
        int bytes = 0;
        
        while (fr.read() != -1) {
            bytes++;
        }
        
        fr.close();
        
        return bytes;
    }
    
    void pack() throws IOException {
        FileWriter fwb = new FileWriter(
                this.path + "/" + this.base_name);
        
        FileWriter fwm = new FileWriter(
                this.path + "/" + this.meta_name);
        
        for (File f : this.files) {
            String name = f.getName();
            int size = this.sizeOfFile(f);
            
            fwm.write(String.format("%s %d%n", name, size));
            
            FileReader fr = new FileReader(f);
            
            int b;
            
            while ((b = fr.read()) != -1) {
                fwb.write(b);
            }
            
            fr.close();
        }
        
        fwb.close();
        fwm.close();
    }
    
    public static void main(String[] args) throws IOException {
        Packer packer = new Packer();
        
        packer.addFile("C:/msdia80.dll");
        packer.addFile("C:/archivos/datos.txt");
        packer.addFile("C:\\Users\\Aula E2\\Desktop\\sesion_1.zip");
        packer.addFile("C:\\Users\\Aula E2\\Desktop\\sesion_2.zip");
        packer.addFile("C:\\Users\\Aula E2\\Desktop\\sesion_3.zip");
        packer.addFile("C:\\Users\\Aula E2\\Desktop\\sesion_4.zip");
        
        packer.pack();
    }
}
